<?php
/**
 * Plugin Name: Reino Socials
 * Plugin URI: http://www.aivahthemes.com/
 * Description: Social Fields in User Contact Methods for Reino Theme
 * Version: 1.0
 * Author: AivahThemes
 * Author URI: URI: http://themeforest.net/user/AivahThemes
 * Text Domain: reino-socials
 * Domain Path: Optional. Plugin's relative directory path to .mo files. Example: /locale/
 * Network: Optional. Whether the plugin can only be activated network wide. Example: true
 * License: GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * function reino_socials
 * Adds custom socials fields in contact information fields available to your WordPress users
 */
if ( ! function_exists( 'reino_socials' ) ) {
	function reino_socials( $user_contact ) {

		// Add socials in user contact methods
		$user_contact['Twitter']   = esc_html__( 'Twitter Username', 'reino-socials' );
		$user_contact['facebook']  = esc_html__( 'Facebook Username', 'reino-socials' );
		$user_contact['google']    = esc_html__( 'Google Plus Username', 'reino-socials' );
		$user_contact['tumblr']    = esc_html__( 'Tumblr Username', 'reino-socials' );
		$user_contact['instagram'] = esc_html__( 'Instagram Username', 'reino-socials' );
		$user_contact['pinterest'] = esc_html__( 'Pinterest Username', 'reino-socials' );

		return $user_contact;
	}
	add_filter( 'user_contactmethods', 'reino_socials',10,1 );
}
